"""Private direct-GIN fixed-storage replay measurement; no model/expert GEMMs."""

import argparse
import hashlib
import json
import math
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

sys.dont_write_bytecode = True
HIDDEN, EXPERTS, TOP_K = 2048, 128, 8
ROUTING_WEIGHT = PREWEIGHTED_ROW = 1.0
EXPECTED_COLLECTED = TOP_K * PREWEIGHTED_ROW
DEFAULT_LIVE = (0, 1, 8, 32, 131, 132, 133, 8192)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def verify_source(root, manifest, digest):
    assert sha(manifest) == digest
    binding = json.loads(manifest.read_text())
    files = binding["files"]
    observed = {
        str(p.relative_to(root))
        for p in root.rglob("*")
        if p.is_file() and "__pycache__" not in p.parts
    }
    assert observed == set(files), "Unexpected/missing immutable source files"
    for name, expected in files.items():
        relative = Path(name)
        assert not relative.is_absolute() and ".." not in relative.parts
        path = root / relative
        assert not path.is_symlink()
        assert sha(path) == (
            expected if isinstance(expected, str) else expected["sha256"]
        )
    return binding


def validate(args, rank, local_rank, world):
    assert world == 8 and 0 <= rank < 8 and local_rank == rank % 4
    assert (
        args.storage > 0
        and args.live_tokens
        and len(set(args.live_tokens)) == len(args.live_tokens)
    )
    assert all(type(n) is int and 0 <= n <= args.storage for n in args.live_tokens)
    assert 0 in args.live_tokens and args.storage in args.live_tokens
    assert (
        1 <= args.sms <= 132
        and args.warmup >= 0
        and args.iterations > 0
        and args.repeats > 0
    )


def native_proof(module):
    binary = Path(module.__file__).resolve()
    build = binary.parent.parent
    signature = json.loads((build / "signature.json").read_text())
    key = hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()
    assert build.name == key and (build / "build.complete").read_text() == key
    return {
        "binary_path": str(binary),
        "binary_sha256": sha(binary),
        "build_key": key,
        "signature": signature,
        "signature_sha256": sha(build / "signature.json"),
        "spec_sha256": sha(build / "spec.json"),
        "build_complete_sha256": sha(build / "build.complete"),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("source-root", "manifest", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--payload", choices=("bf16", "fp8"), required=True)
    parser.add_argument("--storage", type=int, default=8192)
    parser.add_argument(
        "--live-tokens", nargs="+", type=int, default=list(DEFAULT_LIVE)
    )
    parser.add_argument("--sms", type=int, default=132)
    parser.add_argument("--warmup", type=int, default=1000)
    parser.add_argument("--iterations", type=int, default=1000)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument(
        "--routing", choices=("random", "strided", "skew"), default="random"
    )
    parser.add_argument("--routing-seed", type=int, default=20421020)
    args = parser.parse_args()
    rank, local_rank = int(os.environ["RANK"]), int(os.environ["LOCAL_RANK"])
    validate(args, rank, local_rank, int(os.environ["WORLD_SIZE"]))
    assert Path.cwd().resolve() == args.source_root.resolve()
    binding = verify_source(args.source_root, args.manifest, args.manifest_sha256)
    assert not args.output.exists()
    receipt_path = args.output.with_name(args.output.name + f".rank-{rank}.json")
    assert not receipt_path.exists()
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    stat = Path(f"/proc/{os.getpid()}/stat").read_text().rpartition(")")[2].split()
    receipt = {
        "ok": False,
        "rank": rank,
        "local_rank": local_rank,
        "worker": rank < 4,
        "pid": os.getpid(),
        "start_ticks": int(stat[19]),
        "script_sha256": sha(Path(__file__)),
        "source_root": str(args.source_root),
        "manifest_sha256": args.manifest_sha256,
        "cwd": str(Path.cwd()),
        "automatic_retry": False,
    }
    write(receipt_path, receipt)
    try:
        import torch
        import torch.distributed as dist
        from afdep._directional_build import source_digest

        import afdep
        from afdep import DirectionalBuffer as Buffer
        from afdep import DirectionalConfig as Config

        assert (
            Path(afdep.__file__).resolve()
            == args.source_root.resolve() / "afdep/__init__.py"
        )
        assert source_digest() == binding["native_source_sha256"]
        torch.cuda.set_device(local_rank)
        dist.init_process_group("gloo")
        assert dist.get_world_size() == 8
        config = Config(
            args.storage,
            HIDDEN,
            EXPERTS,
            TOP_K,
            ffn_ranks=4,
            attention_ranks=4,
            payload=args.payload,
            num_sms=args.sms,
            num_gin_contexts=8,
            transport_stripes=8,
            rdma_traffic_class=3,
            allow_hybrid_mode=False,
            transport="gin",
        )
        buffer = Buffer(group=dist.group.WORLD, config=config)
        worker = rank < 4
        received = (
            buffer.reserve_worker_receive(bucket=args.storage) if worker else None
        )
        expert = (
            torch.full(
                received.recv_x.shape,
                PREWEIGHTED_ROW,
                dtype=torch.bfloat16,
                device="cuda",
            )
            if worker
            else None
        )
        routes = []
        if not worker:
            source = rank - 4
            route_experts = EXPERTS // 4 if args.routing == "skew" else EXPERTS
            canonical_ids = (
                torch.arange(args.storage, device="cuda")[:, None] * 3
                + torch.arange(TOP_K, device="cuda")[None, :] * 5
                + source
            ) % route_experts
            if args.routing == "random":
                generator = torch.Generator(device="cuda").manual_seed(
                    args.routing_seed + source
                )
                canonical_ids = (
                    torch.rand(
                        (args.storage, EXPERTS), generator=generator, device="cuda"
                    )
                    .topk(TOP_K, dim=1)
                    .indices
                )
            canonical_ids = canonical_ids.long()
            canonical_cpu = canonical_ids.cpu().numpy()
            routes = [
                {
                    "live_tokens": n,
                    "storage": args.storage,
                    "sha256_int64": hashlib.sha256(
                        canonical_cpu[:n].tobytes()
                    ).hexdigest(),
                }
                for n in args.live_tokens
            ]
            x = torch.empty(
                (args.storage, HIDDEN),
                dtype=torch.bfloat16 if args.payload == "bf16" else torch.float8_e4m3fn,
                device="cuda",
            )
            ids = torch.empty_like(canonical_ids)
            weights = torch.empty(
                (args.storage, TOP_K), dtype=torch.float32, device="cuda"
            )
            scale = (
                torch.empty((args.storage, HIDDEN // 128), device="cuda")
                if args.payload == "fp8"
                else None
            )
            live = torch.empty((1,), dtype=torch.int32, device="cuda")
            output = torch.empty(
                (args.storage, HIDDEN), dtype=torch.bfloat16, device="cuda"
            )

        source_pointers = (
            None
            if worker
            else {
                "x": x.data_ptr(),
                "ids": ids.data_ptr(),
                "weights": weights.data_ptr(),
                "scale": None if scale is None else scale.data_ptr(),
                "live": live.data_ptr(),
                "output": output.data_ptr(),
            }
        )

        def prepare(n):
            if worker:
                return
            assert {
                "x": x.data_ptr(),
                "ids": ids.data_ptr(),
                "weights": weights.data_ptr(),
                "scale": None if scale is None else scale.data_ptr(),
                "live": live.data_ptr(),
                "output": output.data_ptr(),
            } == source_pointers
            x.fill_(float("nan"))
            x[:n].fill_(1)
            ids.fill_(-99)
            ids[:n].copy_(canonical_ids[:n])
            weights.fill_(float("nan"))
            weights[:n].fill_(ROUTING_WEIGHT)
            if scale is not None:
                scale.fill_(float("nan"))
                scale[:n].fill_(1)
            output.fill_(float("nan"))
            live.fill_(n)

        def step():
            if worker:
                recv = buffer.worker_receive(bucket=args.storage, out=received)
                buffer.worker_reply(expert, recv.receipt)
            else:
                buffer.source_dispatch(
                    x, ids, weights, scale, bucket=args.storage, live_tokens=live
                )
                buffer.source_collect(output)

        def check(n):
            if not worker:
                torch.testing.assert_close(
                    output[:n],
                    torch.full_like(output[:n], EXPECTED_COLLECTED),
                    rtol=0,
                    atol=0,
                )
                assert bool(torch.isnan(output[n:]).all()), (
                    "Collector wrote outside live prefix"
                )

        for n in args.live_tokens:
            prepare(n)
            step()
            torch.cuda.synchronize()
            check(n)
            dist.barrier()
        prepare(args.storage)
        torch.cuda.synchronize()
        dist.barrier()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            step()
        captures = 1
        torch.cuda.synchronize()
        dist.barrier()
        rows = []
        for n in args.live_tokens:
            prepare(n)
            for _ in range(args.warmup):
                graph.replay()
            if args.warmup == 0:
                graph.replay()  # Untimed correctness replay, even with no warmup.
            torch.cuda.synchronize()
            check(n)
            dist.barrier()
            for repeat in range(args.repeats):
                start, end = (
                    torch.cuda.Event(enable_timing=True),
                    torch.cuda.Event(enable_timing=True),
                )
                dist.barrier()
                wall = time.perf_counter()
                start.record()
                for _ in range(args.iterations):
                    graph.replay()
                end.record()
                end.synchronize()
                local = {
                    "rank": rank,
                    "worker": worker,
                    "gpu_ms": start.elapsed_time(end) / args.iterations,
                    "wall_ms": (time.perf_counter() - wall) * 1000 / args.iterations,
                }
                assert all(
                    math.isfinite(local[k]) and local[k] > 0
                    for k in ("gpu_ms", "wall_ms")
                )
                check(n)
                gathered = [None] * 8
                dist.all_gather_object(gathered, local)
                rows.append(
                    {
                        "live_tokens": n,
                        "storage": args.storage,
                        "repeat": repeat,
                        "ranks": gathered,
                    }
                )
        metadata = {
            "rank": rank,
            "local_rank": local_rank,
            "worker": worker,
            "world_size": 8,
            "config": asdict(config),
            "registered_bytes": buffer.num_buffer_bytes,
            "native_source_sha256": source_digest(),
            "native": native_proof(buffer._module),
            "graph_captures": captures,
            "source_storage": None if worker else args.storage,
            "source_pointers": source_pointers,
            "routing_weight": ROUTING_WEIGHT,
            "preweighted_row": PREWEIGHTED_ROW,
            "expected_collected": EXPECTED_COLLECTED,
            "nccl_runtime_version": buffer._module.get_nccl_version(),
            "nccl_compiled_version": buffer._module.compiled_nccl_version,
            "live_count_pointer": None if worker else live.data_ptr(),
            "routing": routes,
            "device": str(torch.cuda.get_device_properties(local_rank)),
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
            "endpoint_sha256": sha(args.source_root / "afdep/buffer.py"),
        }
        assert (
            metadata["native"]["signature"]["source"] == binding["native_source_sha256"]
        )
        verify_source(args.source_root, args.manifest, args.manifest_sha256)
        assert sha(Path(__file__)) == receipt["script_sha256"]
        del graph
        torch.cuda.synchronize()
        dist.barrier()
        buffer.close()
        receipt.update(
            ok=True,
            metadata=metadata,
            eager_live_checks=args.live_tokens,
            warmup_and_block_oracles=True,
            closed=True,
        )
        write(receipt_path, receipt)
        all_receipts = [None] * 8
        dist.all_gather_object(all_receipts, receipt)
        if rank == 0:
            write(
                args.output,
                {
                    "ok": True,
                    "args": vars(args)
                    | {
                        "source_root": str(args.source_root),
                        "manifest": str(args.manifest),
                        "output": str(args.output),
                    },
                    "metadata": [r["metadata"] for r in all_receipts],
                    "receipts": all_receipts,
                    "measurements": rows,
                    "scope": "Communication only; one maxstorage graph. Initialization/capture/input-count updates/oracles excluded; actual graph replay submission/execution included. Expert output prepared outside timed path. No variable-count-within-block, GEMM or serving claim.",
                },
            )
        dist.destroy_process_group()
    except BaseException as error:
        receipt.update(
            ok=False, error=f"{type(error).__name__}: {error}", automatic_retry=False
        )
        write(receipt_path, receipt)
        raise


if __name__ == "__main__":
    main()
